#!/bin/bash

echo "Ensuring anaconda is loaded (to make Jupyter available)..."
module unload anaconda
module load anaconda

echo "Activating the python environment for this tutorial..."
source /usr/local/share/examples/mole/machinelearning/mlenv/bin/activate

if [ ! -d "/home/moleuser/.local/share/jupyter/kernels/molekernel" ]
then
	echo "Installing molekernel for use with Jupyter..."
	jupyter kernelspec install /usr/local/share/examples/mole/machinelearning/jupyter/molekernel --user
else
	echo "No need to install molekernel because it already exists."
fi

echo "Starting up Jupyter server..."
jupyter-ip.sh
